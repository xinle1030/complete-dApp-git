# defi-staking-app-starter

## To download me simply open up the terminal and run: 

git clone https://github.com/01Clarian/defi-staking-app-starter.git

This code has been revesed engineered from Greg DAPPuniversity.com! If you enjoyed this course go check out his work ;) 
Please feel free to clone and style this project at your own discretion!

## 1 To Clone or download this project simply run: 

git clone - https://github.com/01Clarian/defi-staking-app-starter.git

### 2. cd into the directory and Install the necessary packages

npm install

### 4. Make sure truggle -g is installed

# use truffle compiile 
(compile contracts)

# use truffle migrate --reset 
(migrate contracts on the blockchain)

# use truffle test
to run Moch and Chai testing suite

### Activate Application

Go into the App.js folder and replace the current inactive
API key with your API key.

### `npm run eject`

**Note: this is a one-way operation. Once you `eject`, you can’t go back!**

If you aren’t satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (Webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you’re on your own.

You don’t have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn’t feel obligated to use this feature. However we understand that this tool wouldn’t be useful if you couldn’t customize it when you are ready for it.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).

### Code Splitting

This section has moved here: https://facebook.github.io/create-react-app/docs/code-splitting

### Analyzing the Bundle Size

This section has moved here: https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size

### Making a Progressive Web App

This section has moved here: https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app

### Advanced Configuration

This section has moved here: https://facebook.github.io/create-react-app/docs/advanced-configuration

### Deployment

This section has moved here: https://facebook.github.io/create-react-app/docs/deployment

### `npm run build` fails to minify

This section has moved here: https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify
